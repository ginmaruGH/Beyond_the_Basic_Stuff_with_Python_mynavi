def hello():
    print('Hello!')
    total = 42 + 1
    print('42 plus 1 is %s' % (total))
print('Start!')
hello()
print('Call it again.')
hello()
print('Done.')